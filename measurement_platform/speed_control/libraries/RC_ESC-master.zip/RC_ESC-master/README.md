# RC_ESC / Arduino Library to control Radio Control ESC's

Instructions on how to use this library can be found in the following Robotshop blog post.
https://www.robotshop.com/community/blog/show/rc-speed-controller-esc-arduino-library
